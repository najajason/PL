Cannot GET /bootstrap.js
